### Replication Code for Figure 1 ###

### Title: Does Immigration Boost Public Euroscepticism in EU Member States? ###
### Author: Eddy S. F. Yeung ###
### Version: June 15, 2021 ###

## Set-up
rm(list = ls())
setwd("~/replication-files")
library(tidyverse)
library(haven)
library(grid)
library(Matrix)
library(survey)
library(ggrepel)
library(extrafont)
windowsFonts("Times" = windowsFont("Times")) # required for Windows users

## Import the European Social Survey datasets
ESS1e06_6 <- read_dta("ESS1e06_6.dta")
ESS7e02_2 <- read_dta("ESS7e02_2.dta")

## Define sample designs by applying weights
df1 <- svydesign(ids = ~0, strata = NULL, weights = ~pspwght, data = ESS1e06_6)
df2 <- svydesign(ids = ~0, strata = NULL, weights = ~pspwght, data = ESS7e02_2)

## Compute perceived levels of foreign-born population by country
perceived_level_2002 <- svyby(~noimbro, ~cntry, df1, svymean, na.rm = T) # 2002 wave
perceived_level_2014 <- svyby(~noimbro, ~cntry, df2, svymean, na.rm = T) # 2014 wave

## Generate a new variable that captures the change in 
## perceived levels of foreign-born population by country
perceived_level <- 
  left_join(perceived_level_2002, perceived_level_2014, by = "cntry")
perceived_level <-
  perceived_level %>%
  mutate(change_in_perception = round(noimbro.y - noimbro.x, digits = 1)) %>%
  drop_na()

## Import the OECD foreign-born population datasets
## Downloaded from https://data.oecd.org/migration/foreign-born-population.htm#indicator-chart
actual_level_2002 <- read.csv("OECD-foreign-born-population_2002.csv")
actual_level_2014 <- read.csv("OECD-foreign-born-population_2014.csv")

## Generate a new variable that captures the change in 
## actual levels of foreign-born population by country
actual_level <- 
  left_join(actual_level_2002, actual_level_2014, by = "cntry")
actual_level <- 
  actual_level %>%
  mutate(change_in_reality = foreign_born_pop.y - foreign_born_pop.x)

## Compute the exact figures of overestimation/underestimation
df <- left_join(actual_level, perceived_level, by = "cntry")
colnames(df)[1] <- c("code.x")
df <- subset(df, code.x != "EST") # missing data
overestimation <- 
  df %>%
  rename(country = code.x) %>% 
  select(country, change_in_reality, change_in_perception) %>%
  mutate(overestimation = change_in_perception - change_in_reality) %>% 
  filter(country != "ISR") # drop Israel as it is not a European country

## Reorder country factors for visualization
overestimation$country <- 
  factor(overestimation$country,
         levels = c("HUN","SWE","FRA","NOR","CHE","CZE","IRL","NLD","ESP",
                    "BEL","GBR","FIN","PRT","DNK","SVN","POL","AUT","DEU"))

## Add a color variable for visualization
overestimation <- 
  overestimation %>% 
  mutate(color = ifelse(overestimation < 0, "negative", "positive"))

## Visualize the results (Figure 1)
library(pBrackets)
bracketsGrob <- function(...){
  l <- list(...)
  e <- new.env()
  e$l <- l
  grid:::recordGrob(  {
    do.call(grid.brackets, l)
  }, e)
}
b1 <- bracketsGrob(0.6, 0.53, 0.01, 0.53, h = -0.05, lwd = 2, col = "firebrick1")
b2 <- bracketsGrob(0.99, 0.47, 0.62, 0.47, h = 0.05, lwd = 2, col = "steelblue")
plot <-
  ggplot(overestimation, aes(x = country, y = overestimation)) +
  geom_bar(stat = "identity", position = "identity", aes(fill = color)) +
  scale_fill_manual(values = c(negative = "firebrick1", positive = "steelblue")) +
  coord_cartesian(ylim = c(-6,6)) +
  labs(y = "Difference Between Perceived and Actual Changes in Percentage\nPoints of Foreign-Born Population in Twelve Years (%)",
       x = "Country") +
  theme_bw() +
  theme(text = element_text(size = 12, family = "Times"),
        panel.grid = element_blank(),
        legend.position = "none")
plot <- plot + annotation_custom(b1) + annotation_custom(b2)
plot <-
  plot +
  annotate("text", x = 6, y = 1.5,
           label = "Misalignment due to underestimation",
           color = "firebrick1",
           family = "Times") +
  annotate("text", x = 15, y = -1.5,
           label = "Misalignment due to overestimation",
           color = "steelblue",
           family = "Times")
plot
ggsave("Figure 1.pdf", width = 8, height = 5)
