README File for Eddy S. F. Yeung's Article

"Does Immigration Boost Public Euroscepticism in EU Member States?"

European Union Politics

List of files required to replicate each reported analysis in the main text:
- Table 1: "instrumental-euroscepticism_code.do" (code) and "instrumental-euroscepticism_data.dta" (data)
- Table 2: "affective-euroscepticism_code.do" (code) and "affective-euroscepticism_data.dta" (data)
- Figure 1: "fig1_misalignment.R" (code), "ESS1e06_6.dta" (data), "ESS7e02_2.dta" (data), "OECD-foreign-born-population_2002.csv" (data), and "OECD-foreign-born-population_2014.csv" (data)
- Figure 3: "fig3-fig4_year-by-year-estimates.R" (code) and "fig3-fig4_year-by-year-estimates.csv" (data)
- Figure 4: "fig3-fig4_year-by-year-estimates.R" (code) and "fig3-fig4_year-by-year-estimates.csv" (data)
- Subset analysis with EU-15 only: "instrumental-euroscepticism_code.do" (code), "affective-euroscepticism_code.do" (code), "instrumental-euroscepticism_data.dta" (data), and "affective-euroscepticism_data.dta" (data)

List of files required to replicate each reported analysis in the Online appendix:
- Table 2: "instrumental-euroscepticism_code.do" (code) and "instrumental-euroscepticism_data.dta" (data)
- Table 3: "affective-euroscepticism_code.do" (code) and "affective-euroscepticism_data.dta" (data)
- Table 4: "instrumental-euroscepticism_code.do" (code) and "instrumental-euroscepticism_data.dta" (data)
- Table 5: "affective-euroscepticism_code.do" (code) and "affective-euroscepticism_data.dta" (data)
- Table 6: "instrumental-euroscepticism_code.do" (code) and "instrumental-euroscepticism_data.dta" (data)
- Table 7: "affective-euroscepticism_code.do" (code) and "affective-euroscepticism_data.dta" (data)

Note 1: Replicating Tables 1 and 2 of the main text will take some time in Stata due to computational complexity.
Note 2: Replicating Tables 3 to 7 of the Online appendix will take some time in Stata due to computational complexity.