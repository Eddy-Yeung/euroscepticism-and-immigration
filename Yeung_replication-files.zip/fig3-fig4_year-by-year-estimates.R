### Figures 3 and 4: Coefficients for Immigration Variables by Year ###
### Eddy S. F. Yeung ###
### June 7, 2021 ###

## Set-up
rm(list = ls())
setwd("~/replication-files")
library(tidyverse)
library(ggpubr)
library(plotrix)
library(extrafont)

## Import the dataset
df <- read.csv("fig3-fig4_year-by-year-estimates.csv")

## Subset the dataset
df_linear_set1 <- subset(df, df$set == 1 & df$estimator == "linear")
df_linear_set2 <- subset(df, df$set == 2 & df$estimator == "linear")
df_ologit_set1 <- subset(df, df$set == 1 & df$estimator == "ologit")
df_ologit_set2 <- subset(df, df$set == 2 & df$estimator == "ologit")

## Figure 3A
## Visualization for multilevel linear estimates in Set 1 (Instrumental Euroscepticism)
ggplot(df_linear_set1,
       aes(x = year, y = estimate,
           shape = Variable, fill = Variable, colour = Variable)) +
  geom_pointrange(aes(ymin = lower_bound, ymax = upper_bound),
                  position = position_dodge(.5)) +
  geom_point(size = 1, position = position_dodge(.5)) +
  scale_fill_manual(values = c("blue","red")) +
  scale_color_manual(values = c("blue","red")) +
  scale_shape_manual(values = c(21,24)) +
  xlab("Year") + ylab("Estimated Coefficient") +
  scale_x_continuous(breaks = c(2009,2010,2011,2013,2015,2016,2017)) +
  coord_cartesian(ylim = c(-0.5,0.5)) +
  theme_bw() +
  theme(text = element_text(colour = "black", size = 14, family = "Times"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.justification = c(1,1), legend.position = c(0.98,0.98),
        legend.background = element_blank(),
        legend.box.background = element_rect(color = "black"),
        legend.key.size = unit(1.5, "line")) +
  geom_hline(yintercept = 0, linetype = "longdash")
ggsave("Figure 3A.pdf", width = 6, height = 6)

## Figure 3B
## Visualization for multilevel linear estimates in Set 2 (Affective Euroscepticism)
ggplot(df_linear_set2,
       aes(x = year, y = estimate,
           shape = Variable, fill = Variable, colour = Variable)) +
  geom_pointrange(aes(ymin = lower_bound, ymax = upper_bound),
                  position = position_dodge(.5)) +
  geom_point(size = 1, position = position_dodge(.5)) +
  scale_fill_manual(values = c("blue","red")) +
  scale_color_manual(values = c("blue","red")) +
  scale_shape_manual(values = c(21,24)) +
  xlab("Year") + ylab("Estimated Coefficient") +
  scale_x_continuous(breaks = c(2010,2012,2013,2014,2015,2016,2017)) +
  coord_cartesian(ylim = c(-0.5,0.5)) +
  theme_bw() +
  theme(text = element_text(colour = "black", size = 14, family = "Times"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.justification = c(1,1), legend.position = c(0.98,0.98),
        legend.background = element_blank(),
        legend.box.background = element_rect(color = "black"),
        legend.key.size = unit(1.5, "line")) +
  geom_hline(yintercept = 0, linetype = "longdash")
ggsave("Figure 3B.pdf", width = 6, height = 6)

## Figure 4A
## Visualization for multilevel ordered logistic estimates in Set 1 (Instrumental Euroscepticism)
ggplot(df_ologit_set1,
       aes(x = year, y = estimate,
           shape = Variable, fill = Variable, colour = Variable)) +
  geom_pointrange(aes(ymin = lower_bound, ymax = upper_bound),
                  position = position_dodge(.5)) +
  geom_point(size = 1, position = position_dodge(.5)) +
  scale_fill_manual(values = c("blue","red")) +
  scale_color_manual(values = c("blue","red")) +
  scale_shape_manual(values = c(21,24)) +
  xlab("Year") + ylab("Estimated Coefficient") +
  scale_x_continuous(breaks = c(2009,2010,2011,2013,2015,2016,2017)) +
  coord_cartesian(ylim = c(-0.5,0.5)) +
  theme_bw() +
  theme(text = element_text(colour = "black", size = 14, family = "Times"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.justification = c(1,1), legend.position = c(0.98,0.98),
        legend.background = element_blank(),
        legend.box.background = element_rect(color = "black"),
        legend.key.size = unit(1.5, "line")) +
  geom_hline(yintercept = 0, linetype = "longdash")
ggsave("Figure 4A.pdf", width = 6, height = 6)

## Figure 4B
## Visualization for multilevel ordered logistic estimates in Set 2 (Affective Euroscepticism)
ggplot(df_ologit_set2,
       aes(x = year, y = estimate,
           shape = Variable, fill = Variable, colour = Variable)) +
  geom_pointrange(aes(ymin = lower_bound, ymax = upper_bound),
                  position = position_dodge(.5)) +
  geom_point(size = 1, position = position_dodge(.5)) +
  scale_fill_manual(values = c("blue","red")) +
  scale_color_manual(values = c("blue","red")) +
  scale_shape_manual(values = c(21,24)) +
  xlab("Year") + ylab("Estimated Coefficient") +
  scale_x_continuous(breaks = c(2010,2012,2013,2014,2015,2016,2017)) +
  coord_cartesian(ylim = c(-0.5,0.5)) +
  theme_bw() +
  theme(text = element_text(colour = "black", size = 14, family = "Times"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        legend.justification = c(1,1), legend.position = c(0.98,0.98),
        legend.background = element_blank(),
        legend.box.background = element_rect(color = "black"),
        legend.key.size = unit(1.5, "line")) +
  geom_hline(yintercept = 0, linetype = "longdash")
ggsave("Figure 4B.pdf", width = 6, height = 6)
